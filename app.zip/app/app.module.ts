import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { CloneUserModule } from './clone-user/clone-user.module'
import { cloneUserRoutes } from './clone-user/clone-user.routing'
import { WelcomeComponent } from './menu/welcome.component'
import { CloneUserComponent } from './clone-user/clone-user.component'
import { SearchUserComponent } from './widgets/search-user/search-user.component'
import { CreateUserComponent } from './widgets/create-user/create-user.component'

@NgModule({
  imports: [
    BrowserModule,
    HttpModule,
    CloneUserModule,
    RouterModule.forRoot([
      { path: 'welcome', component: WelcomeComponent },
      ...cloneUserRoutes,
      { path: '', redirectTo: 'welcome', pathMatch: 'full' },
      { path: '**', redirectTo: 'welcome', pathMatch: 'full' },
      { path: '**', redirectTo: 'welcome', pathMatch: 'full' }
    ])
  ],
  declarations: [
    AppComponent, WelcomeComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
