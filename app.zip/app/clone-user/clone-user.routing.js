"use strict";
var clone_user_component_1 = require('./clone-user.component');
var create_user_component_1 = require('../widgets/create-user/create-user.component');
exports.cloneUserRoutes = [
    { path: 'CloneUser', component: clone_user_component_1.CloneUserComponent },
    { path: 'CloneUser/:id', component: create_user_component_1.CreateUserComponent }
];
//# sourceMappingURL=clone-user.routing.js.map