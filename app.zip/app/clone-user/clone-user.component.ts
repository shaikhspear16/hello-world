
import {Component} from '@angular/core'
@Component({
    selector: 'nt-clone-user',
    templateUrl:`app/clone-user/clone-user.component.html`
})

export class CloneUserComponent 
{

    
}