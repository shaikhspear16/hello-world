import {NgModule} from '@angular/core'

import {CloneUserComponent} from './clone-user.component'
import {SearchUserComponent} from '../widgets/search-user/search-user.component'
import {CreateUserComponent} from '../widgets/create-user/create-user.component'
import { RouterModule } from '@angular/router';
import { FormsModule }   from '@angular/forms';

@NgModule({
exports:[CloneUserComponent],
imports:[FormsModule,RouterModule],
declarations:[CloneUserComponent,SearchUserComponent,CreateUserComponent]
})
export class CloneUserModule
{

}