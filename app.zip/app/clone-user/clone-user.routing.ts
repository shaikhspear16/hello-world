import { CloneUserComponent } from './clone-user.component'
import { SearchUserComponent } from '../widgets/search-user/search-user.component'
import { CreateUserComponent } from '../widgets/create-user/create-user.component'
import { Routes} from '@angular/router';

export const cloneUserRoutes: Routes = [
    { path: 'CloneUser', component: CloneUserComponent },
    { path: 'CloneUser/:id', component: CreateUserComponent }
];

