"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var clone_user_component_1 = require('./clone-user.component');
var search_user_component_1 = require('../widgets/search-user/search-user.component');
var create_user_component_1 = require('../widgets/create-user/create-user.component');
var router_1 = require('@angular/router');
var forms_1 = require('@angular/forms');
var CloneUserModule = (function () {
    function CloneUserModule() {
    }
    CloneUserModule = __decorate([
        core_1.NgModule({
            exports: [clone_user_component_1.CloneUserComponent],
            imports: [forms_1.FormsModule, router_1.RouterModule],
            declarations: [clone_user_component_1.CloneUserComponent, search_user_component_1.SearchUserComponent, create_user_component_1.CreateUserComponent]
        }), 
        __metadata('design:paramtypes', [])
    ], CloneUserModule);
    return CloneUserModule;
}());
exports.CloneUserModule = CloneUserModule;
//# sourceMappingURL=clone-user.module.js.map