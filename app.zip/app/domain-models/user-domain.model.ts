
export class User
{
  cloneId:number  
  userName:string
  userDescription:string
  emailId:string
  ssoKey:string
 
}
