import { Component } from '@angular/core'
import { User } from './../../domain-models/user-domain.model'


@Component({
    selector: 'nt-search-user',
    templateUrl: `app/widgets/search-user/search-user.component.html`
})

export class SearchUserComponent {
    user:User = new User();
}