import {Injectable} from '@angular/core'

import {User} from './../../domain-models/user-domain.model'

@Injectable()
export class CreateUserService{
    createUser(user:User):void
    {
        //api call 
    }
}