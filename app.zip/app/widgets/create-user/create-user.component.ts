import{Component} from '@angular/core'
import {User} from './../../domain-models/user-domain.model'
import {CreateUserService} from './create-user.service'



@Component({
  selector:'nt-create-user',
  templateUrl:'app/widgets/create-user/create-user.component.html',
  providers:[CreateUserService]
})
export class CreateUserComponent 
{
    user:User = new User();
    constructor(private _userservice:CreateUserService)
    {}
   
    Create():void
    {
     this._userservice.createUser(this.user);

    }

}