import { Component } from '@angular/core';

@Component({
    templateUrl: 'app/menu/welcome.component.html'
})
export class WelcomeComponent {
    public pageTitle: string = 'Welcome';
}
